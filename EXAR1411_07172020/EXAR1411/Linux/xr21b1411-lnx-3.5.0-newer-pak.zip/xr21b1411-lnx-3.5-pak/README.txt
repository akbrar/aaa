XR21b1411 USB Serial
==================

Version 0.5, 06/08/2013

The source code is compatible with these kernel versions (and probably others):
    3.5.0 and newer.

Installation
------------

* Make sure the XR21b1411 device is unplugged from the Linux host.

* Make sure that the cdc_acm driver and any previously loaded xr21b1411
  driver modules are not loaded. (You may need root privileges for executing
  these commands.)

	# rmmod cdc_acm
	# rmmod xr21b1411
	# modprobe -r usbserial

* Make XR21b1411 driver module. (Open a terminal window and go to the folder
  where the source code is copied and run 
	# make
 This will create xr21b1411.ko if there were no errors.

* Install the XR21b1411 driver module.

	# modprobe usbserial
	# insmod ./xr21b1411.ko

* Plug XR21b1411 device into the host.  You should see /dev/ttyUSB[x] created.


Operation
---------

The XR21b1411 driver presents a standard Linux TTY interface that can be
configured and manipulated with the usual APIs (tcgetattr(),
tcsetattr(), ioctl(), read(), write(), etc).

The normal supported character modes are 7N1, 7N2, 7P1, 7P2, 8N1, 8N2,
8P1, 8P2, with odd, even, mark and space parity.

XR21b1411 also supports 9N1 and 9N2.  It is enabled by using the CS5
character size.  In this mode a 9-bit character can be written to the
device with two bytes.  Bits 0..7 of the character are taken from the
first byte, and bit-8 of the character is taken from bit-0 of the
second byte.

Similarly, a 9-bit character can be read from the device as a pair of
bytes.  Bits 0..7 of the character are in the first byte, and bit-8 of
the character is taken from bit-0 of the second byte.  Bits 1..7 of
the second byte are undefined.

